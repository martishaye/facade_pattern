
package facade;

public interface Shape {
    void draw();
    
}
